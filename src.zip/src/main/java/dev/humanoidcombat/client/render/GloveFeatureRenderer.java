package dev.humanoidcombat.client.render;

public final class GloveFeatureRenderer {

    private GloveFeatureRenderer() {
    }

}