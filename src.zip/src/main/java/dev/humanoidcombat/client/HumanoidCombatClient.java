package dev.humanoidcombat.client;

import net.fabricmc.api.ClientModInitializer;
import dev.humanoidcombat.HumanoidCombat;

public final class HumanoidCombatClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        HumanoidCombat.LOGGER.info(
            "HumanoidCombat client initialized."
        );
    }
}