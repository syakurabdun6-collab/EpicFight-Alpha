package dev.humanoidcombat.client;

import dev.humanoidcombat.HumanoidCombat;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.LivingEntityRenderLayerRegistrationCallback;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.client.renderer.entity.player.AvatarRenderer;

public final class HumanoidCombatClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        HumanoidCombat.LOGGER.info("HumanoidCombat client initialized.");

        LivingEntityRenderLayerRegistrationCallback.EVENT.register(
            (entityType, entityRenderer, registrationHelper, context) -> {
                if (entityType == EntityTypes.PLAYER
                        && entityRenderer instanceof AvatarRenderer<?>) {
                    HumanoidCombat.LOGGER.info(
                        "Player renderer detected for glove layer."
                    );
                }
            }
        );
    }
}package