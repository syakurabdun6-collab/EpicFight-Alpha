
package dev.humanoidcombat.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.LivingEntityRenderLayerRegistrationCallback;
import dev.humanoidcombat.HumanoidCombat;

public final class HumanoidCombatClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        HumanoidCombat.LOGGER.info(
            "HumanoidCombat client initialized."
        );

        LivingEntityRenderLayerRegistrationCallback.EVENT.register(
            (entityType, entityRenderer, registrationHelper, context) -> {
                HumanoidCombat.LOGGER.info(
                    "Living entity render layer registration available."
                );
            }
        );
    }
}
