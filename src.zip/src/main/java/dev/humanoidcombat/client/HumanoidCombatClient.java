package dev.humanoidcombat.client;

import dev.humanoidcombat.HumanoidCombat;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.LivingEntityRenderLayerRegistrationCallback;

public final class HumanoidCombatClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        HumanoidCombat.LOGGER.info("HumanoidCombat client initialized.");

        LivingEntityRenderLayerRegistrationCallback.EVENT.register(
            (entityType, entityRenderer, registrationHelper, context) -> {
                // Cosmetic glove renderer will be registered here.
            }
        );
    }
}