package dev.humanoidcombat;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class HumanoidCombat implements ModInitializer {

    public static final String MOD_ID = "humanoidcombat";
    public static final Logger LOGGER =
            LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("HumanoidCombat initialized!");
        LOGGER.info("Classic and Slim player model support is being prepared.");
    }
}