package dev.humanoidcombat;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Humanoid Combat: cosmetic-only development scaffold.
 *
 * NOTE: The exact item registry API can change between Minecraft versions.
 * This class deliberately remains a minimal initializer until the 26.1.2
 * mappings/API signatures are verified in a real Gradle build.
 */
public final class HumanoidCombat implements ModInitializer {
    public static final String MOD_ID = "humanoidcombat";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("Humanoid Combat cosmetic project initialized.");
        LOGGER.info("Cosmetic glove assets are present; item registration is pending API verification.");
    }
}
