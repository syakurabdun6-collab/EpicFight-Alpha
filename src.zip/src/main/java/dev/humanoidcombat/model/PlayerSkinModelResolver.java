package dev.humanoidcombat.model;

public final class PlayerSkinModelResolver {

    private PlayerSkinModelResolver() {
    }

    public static PlayerModelProfile resolve(boolean slim) {
        return slim
                ? PlayerModelProfile.SLIM
                : PlayerModelProfile.CLASSIC;
    }
}