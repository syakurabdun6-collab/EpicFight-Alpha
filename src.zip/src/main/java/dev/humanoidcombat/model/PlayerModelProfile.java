package dev.humanoidcombat.model;

public enum PlayerModelProfile {
    CLASSIC(4),
    SLIM(3);

    private final int armWidth;

    PlayerModelProfile(int armWidth) {
        this.armWidth = armWidth;
    }

    public int getArmWidth() {
        return armWidth;
    }
}